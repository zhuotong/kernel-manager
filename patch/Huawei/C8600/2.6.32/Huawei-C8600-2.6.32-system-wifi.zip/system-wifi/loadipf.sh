#!/bin/sh
cd /system/wifi/
insmod ar6000.ko
sleep 5
#BU5D08205 sihongfang 20100417 begin
#delete
#BU5D08205 sihongfang 20100417 end

