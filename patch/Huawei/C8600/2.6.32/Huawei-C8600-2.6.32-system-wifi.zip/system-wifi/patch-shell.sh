#!/system/bin/sh
ROOT_DIR="/mnt/sdcard/.kernel/system-wifi"
cd $ROOT_DIR
if [ -d "$ROOT_DIR" ]
then
	for file in `ls $ROOT_DIR`
	do
		if [ $file = "patch-shell.sh" ]
		then
			continue	
		else
			SRC_FILE=$ROOT_DIR"/"$file; export SRC_FILE
			busybox cp $SRC_FILE /system/wifi/
		fi
	done
fi
echo "Done"
