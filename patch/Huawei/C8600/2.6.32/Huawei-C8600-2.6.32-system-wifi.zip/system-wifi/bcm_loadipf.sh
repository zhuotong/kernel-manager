#!/bin/sh
#/* < DTS2010070900348 sihongfang 20100710 begin */
insmod /wifi/dhd.ko "firmware_path=/system/wifi/firmware.bin nvram_path=/system/wifi/nvram.txt"
#/* DTS2010070900348 sihongfang 20100710 end > */
sleep 5
